<?php
include('includes/init.php');
// require 'app/router/Route.php';
// require 'app/model/Model.php';
// require 'app/router/Router.php';
// require 'app/controller/Controller.php';
// require 'app/views/View.php';

// require 'app/model/AddModel.php';
// require 'CurrencyConverter.php';

// require 'CurrencyConverterView.php';
// require 'app/controller/CurrencyConverterController.php';
// require 'app/views/AddView.php';

// require 'app/model/UserListModel.php';
// require 'app/controller/UserListController.php';
// require 'app/views/UserListView.php';

// require 'app/Dice/Dice.php';
// require 'app/Router/Router.php';
// require 'app/Router/Route.php';
// require 'app/Router/Configuration.php';
// require 'app/Router/Convention.php';


// require 'app/model/UserEditModel.php';
// require 'app/controller/UserEditController.php';
// require 'app/views/UserEditView.php';


// include('init.php');
// class FrontController {
// 	private $controller;
// 	private $view;
	
// 	public function __construct(Router $router, $routeName, $action = null) {
// 		$route = $router->getRoute($routeName);
// 		$modelName = $route->model;
// 		$controllerName = $route->controller;
// 		$viewName = $route->view;
		
// 		$model = new $modelName;
// 		$this->controller = new $controllerName($model);
// 		$this->view = new $viewName($routeName, $model);
		
		
// 		if (!empty($action)) $this->controller->{$action}();
// 	}
	
// 	public function output() {
// 		//This allows for some consistent layout generation code 
// 		$header = '<h1>Hello world examples</h1>';
// 		return $header . '<div>' . $this->view->output() . '</div>';
// 	}
// }


// $frontController = new FrontController(new Router,  isset($_GET['route']) ? $_GET['route'] : null, isset($_GET['action']) ? $_GET['action'] : null);
// echo $frontController->output();


// add user using mvc boom panis

// $model = new CurrencyConverter();

// $controller = new CurrencyConverterController($model);


// if (isset($_GET['action'])) $controller->{$_GET['action']}($_POST);



// $gbpView = new CurrencyConverterView($model);

// echo $gbpView->output();





// list user using mvc boom panis

// $model = new UserListModel();

// $controller = new UserListController($model);

// $listUser = new UserListView($model);

// echo $listUser->render();






// edit user using mvc boom panis

// $model = new UserEditModel();

// $controller = new UserEditController($model);

// if (isset($_GET['action'])) $controller->{$_GET['action']}($_POST);

// $editUser = new UserEditView($model);

// echo $editUser->render();





$dice = new \Dice\Dice;


$rule = [];
$rule['shared'] = true;

$dice->addRule('UserListView', $rule);

$rule = [];
$rule['instanceOf'] = 'Route';
$rule['constructParams'] = ['UserListView', 'UserListController'];

// $rule = [
// 		'instanceOf' => 'Route',
// 		'constructParams' => ['UserListView','UserListController']
// 		];

$rule['inherit'] = false;

$dice->addRule('UserListView', $rule);





$router = new \Router\Router;

$router->addRule(new \Router\Configuration($dice));

$router->addRule(new \Router\Convention($dice));

// $router->addRule(new \Router\Default($dice));


$url =  explode('/', $_SERVER['REQUEST_URI']);



$urlfiltered = array($url[2],$url[3]);
// print_r($urlfiltered);



$route = $router->getRoute($urlfiltered);



?>