<?php
// Define configuration
define("_BASE_DIR", "config/");