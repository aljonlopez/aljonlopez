<?php
include 'CurrencyConverter.php';
class CurrencyConverterView {

    private $converter;

    // private $currency;

    

    public function __construct(CurrencyConverter $converter) {

        $this->converter = $converter;

        // $this->currency = $currency;

    }

    

    public function output() {

        $html = '<form action="?action=convert" method="post"><label>username:</label><input name="amount" type="text" value=""/>
        <input name="pass" type="text" value=""/>
        <input type="submit" value="Convert"/></form>';

        

        return $html;

    }

}

?>