<!DOCTYPE html>
<html>
 <head>
  <meta charset="charset=utf-8">
  <title><?php echo $pagetitle; ?></title>
 </head>
 <body>
 <a href="?route=home">Home</a> | 
  <a href="?route=about">About</a>
  <h1><?php echo $data; ?></h1>
 </body>
</html>