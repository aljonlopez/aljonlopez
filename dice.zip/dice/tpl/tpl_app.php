<!DOCTYPE html>
<html>
 <head>
  <meta charset="charset=utf-8">
  <title><?php echo $pagetitle; ?></title>
 </head>
 <body>
 <a href="?route=home">Home</a> | 
  <a href="?route=about">AAA Management</a> |
  <a href="?route=user">Card Management</a>	|
  <a href="?route=user">Billing Management</a>	|
  <a href="?route=user">Accounting</a>	|
  <a href="?route=user">Reports</a>	|
  <a href="?route=user">Configuration</a>	
  <h1><?php echo $html; ?></h1>
 </body>
</html>