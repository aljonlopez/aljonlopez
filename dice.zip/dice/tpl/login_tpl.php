<!DOCTYPE html>
<html>
 <head>
  <meta charset="charset=utf-8">
  <title><?php echo $pagetitle; ?></title>
 </head>
 <body>
 
  <h1><?php echo $data; ?></h1>
 </body>
</html>