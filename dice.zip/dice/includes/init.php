<?php
require 'config/config.php';
require 'lib/Database.php';
require 'lib/Autoloader.php';


$autoloader = new Autoloader();
$autoloader->addDirectories($classdirec);
$autoloader->register();

?>