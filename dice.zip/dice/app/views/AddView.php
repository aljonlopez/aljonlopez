<?php

include 'app/model/AddModel.php';

class AddView {

    private $converter;

    private $currency;

    

    

    public function __construct(AddModel $converter, $currency) {

        $this->converter = $converter;

        $this->currency = $currency;

    }

    

    public function output() {

        $html = '<form action="?action=convert" method="post">
                <label>username:</label>
                <input name="username" type="text"/>
                <input type="submit" value="Convert"/>
                </form>';

        

        return $html;

    }

}

?>