<?php
// class View {
// 	private $model;
// 	private $route;
	
// 	public function __construct($route, Model $model) {
// 		$this->route = $route;
// 		$this->model = $model;
// 	}
	
// 	public function output() {
// 		return '<a href="index.php?route=' . $this->route . '&action=textActive">' . $this->model->text . '</a>';
// 	}	
// }
$model = new UserListModel();

$controller = new UserListController($model);

$listUser = new UserListView($model);

echo $listUser->render();
?>