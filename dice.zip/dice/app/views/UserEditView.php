<?php
class UserEditView  {

    private $model;

    

   public function __construct(UserEditModel $model) {

        $this->model = $model;

    } 

    

    public function render() {

        $user = $this->model->getUser();
        foreach ($user as $value) {
        	
        }
        

          return '<h2>Editing user ' . $value['username'] . '</h2>

          <form action="?action=save" method="post"><label>username:</label><input name="amount" type="text" value="'.$value['username'].'"/>
        <input name="pass" type="text" value="'.$value['password'].'"/>
        <input name="id" type="hidden" value="'.$value['user_id'].'"/>
        <input type="submit" value="Convert"/></form>';   

    }

}
?>