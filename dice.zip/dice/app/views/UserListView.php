<?php
class UserListView{

    private $model;

    

    public function __construct(UserListModel $model) {
        $this->model = $model;

    } 

    

    public function render() {

          $html = '<h2>User List</h2>';

          $html .= '<table border="1">
          <tr>
            <td>id</td>
            <td>username</td>
            <td>password</td>
            </tr>
            
          ';

          //loop through users an generate a HTML table.  
          $users = $this->model->findAll();
          
          foreach ($users as $value) 
            // $field = (object) $value;
            $html .= '<tr> <td>' . $value['user_id'] . '</td> <td>' . $value['username'] . '</td> <td>' . $value['password'] . '</td> </tr>';
          
          $html .= '</table>';

          return $html;

    }



}
?>