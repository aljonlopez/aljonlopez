<?php
class Model {
	public $text;
	
	public function __construct() {
		$this->text = '
			<form action="?action=convert" method="post">
				<input name="currency" type="hidden"/>
				<input name="amount" type="text"/>
				<input type="submit" value="Convert"/>
			</form>';
	}		
}
?>