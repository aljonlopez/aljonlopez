<?php

class AddModel {

    private $baseValue = 0;

    

    private $rates = [

        'GBP' => 1.0,

        'USD' => 0.6,

        'EUR' => 0.83,

        'YEN' => 0.0058,
        'num1' => 5        

    ];

    

    public function get($currency) {

         if (isset($this->rates[$currency])) {

            $rate = 1/$this->rates[$currency];

            return $rate + $currency;

        }

        else return 0;        

    }

    

    public function set($amount, $currency = 'GBP') {

        if (isset($this->rates[$currency])) {

            $this->baseValue = $amount * $this->rates[$currency];

        }

    }

    public function add($rec1){
         if (isset($rec1)) {

            // $rate = 1/$this->rates[$currency];

            $this->baseValue = $rec1 + 2;

        }

    }

    

}
?>