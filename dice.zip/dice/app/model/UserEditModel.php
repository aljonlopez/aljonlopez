<?php
class UserEditModel {

    // private $pdo;

    private $user;

    

    // public function __construct(PDO $pdo) {

    //     $this->pdo = $pdo;

    // }

    

    public function load($id) {

        $stmt = $this->pdo->prepare('SELECT * FROM user WHERE id = ?');

        $stmt->execute([$id]);

        return $stmt->fetch();

    }

    

    public function getUser() {

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "user";

        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = 'SELECT * FROM login WHERE user_id = 7';
        $result = mysqli_query($conn, $sql);
        // return $result;
        if (mysqli_num_rows($result) > 0) {
            // output data of each row
            $data = array();
            while($row = mysqli_fetch_assoc($result)) {
                $data[] = $row;
            }
            return $data;
        } else {
            echo "0 results";
        }
        
        // return $this->user;

    }

    public function save($amount, $pass, $id) {

        // if (isset($this->rates[$currency])) {

            // $this->baseValue = $amount * $this->rates[$currency];

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "user";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "UPDATE login SET username = '".$amount."', password='".$pass."' WHERE user_id = '".$id."' ";

            if (mysqli_query($conn, $sql)) {
                echo "Record Updated successfully";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

        // }

    }
}
?>