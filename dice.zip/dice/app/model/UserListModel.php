<?php
class UserListModel {

    // private $pdo;

    // private $sort = 'name ASC';

    

    // public function __construct(PDO $pdo) {

    //     $this->pdo = $pdo;

    // }

    

    public function setSort($sort) {

        $this->sort = $sort;

    }

    

    public function findAll() {

         $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "user";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

        $sql = 'SELECT * FROM login';
        $result = mysqli_query($conn, $sql);
        // return $result;
if (mysqli_num_rows($result) > 0) {
    // output data of each row
    $data = array();
    while($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    return $data;
} else {
    echo "0 results";
}

    }

}
?>