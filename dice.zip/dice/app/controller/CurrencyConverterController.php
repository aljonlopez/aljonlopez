<?php
class CurrencyConverterController {

    private $currencyConverter;

    

    public function __construct(CurrencyConverter $currencyConverter) {

        $this->currencyConverter = $currencyConverter;

    }

    

    public function convert($request) {
    	print_r($request);
        if (isset($request['pass']) && isset($request['amount'])) {

            $this->currencyConverter->set($request['amount'], $request['pass']);

        }

    }

}
?>