<?php
class AddInfo {

    private $addModel;

    

    public function __construct(AddModel $addModel) {

        $this->addModel = $addModel;

    }

    

    public function convert($request) {

        if (isset($request['amount'])) {

            $this->addModel->add($request['amount']);

        }

    }

}
?>