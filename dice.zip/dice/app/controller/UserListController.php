<?php
class UserListController{

    private $model;

    

    public function __construct(UserListModel $model) {

        $this->model = $model;

    }

    

    public function sort($order){

        $this->model->setSort($order);

    }

}
?>