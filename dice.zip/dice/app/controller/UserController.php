<?php
class UserController extends Controller {

    public function showList() {

        $users = $this->model->findAll();

        $this->set('users', $users);

        $this->render('list.tpl');

    }

    

    public function sortList($order) {

        $users = $this->model->setSort($order);

        $this->set('users', $users);

        $this->render('list.tpl');

    }

    

    public function edit($id) {

        $user = $this->model->findById($id);

        $this->set('user', $user);

        $this->render('form.tpl');

    }

    

    public function save() {

        if ($this->model->save($_POST)) {

            $this->render('success.tpl');

        }

        else {

            $user = $this->model->findById($_POST['id']);

            $this->set('user', $_POST);

            $this->render('form.tpl');

        }

    }

}
?>