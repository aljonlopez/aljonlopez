<?php
include 'Router.php';

class FrontController {

    private $controller;

    private $view;

    

    public function __construct(Router $router, $routeName, $action = null) {

    

        //Fetch a route based on a name, e.g. "search" or "list" or "edit"

        $route = $router->getRoute($routeName);

        

        //Fetch the names of each component from the router

        $modelName = $route->model;

        $controllerName = $route->controller;

        $viewName = $route->view;

        

        //Instantiate each component

        $model = new $modelName;

        $this->controller = new $controllerName($model);

        $this->view = new $viewName($routeName, $model);

        

        //Run the controller action

        if (!empty($action)) $this->controller->{$action}();

    }

    

    public function output() {

        //Finally a method for outputting the data from the view 

        //This allows for some consistent layout generation code such as a page header/footer

        $header = '<h1>Hello world example</h1>';

        return $header . '<div>' . $this->view->output() . '</div>';

    }

}
?>