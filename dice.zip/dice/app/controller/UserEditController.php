<?php
class UserEditController  {



    public function __construct(UserEditModel $model) {

        $this->model = $model;

    }    

        

    public function main($id) { 

        $this->model->load($id);    

    }

    

    public function save($request) {
    	print_r($request);
        if (isset($request['pass']) && isset($request['amount'])) {

            $this->model->save($request['amount'], $request['pass'],$request['id']);

        }       

    }

}
?>