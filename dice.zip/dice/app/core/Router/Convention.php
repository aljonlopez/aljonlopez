<?php
namespace Router;



class Convention implements \Router\Rule {

    private $dice;



    public function __construct(\Dice\Dice $dice) {

        $this->dice = $dice;

    }



    public function find(array $route) {


        //The name of the class

        $className = '\\' . array_shift($route) . '\\' . array_shift($route);



        $viewName = $className . '\\View';


        //If the view doesn't exist, the convention rule can't continue

        if (!class_exists($viewName)) return false;

        

        $controllerName = $className . '\\Controller';

        

        //Auto-generate a rule for a route if it's not already been generated

        if ($this->dice->getRule('$autoRoute_' . $className) == $this->dice->getRule('*')) {

            $rule = new \Dice\Rule;

            

            //Dice will be creating a Route object and pass it a specific view and controller

            $rule->instanceOf = 'Route';

            

            //The first parameter will be a view

            $rule->constructParams[] = new \Dice\Instance($viewName);



            //Only pass the controller to the route object if the controller exists

            $rule->constructParams[] = (class_exists($controllerName)) ? new \Dice\Instance($controllerName) : null;



            //The model (or ViewModel) will need to be shared between the controller and view

            $modelName = $className . '\\ViewModel';



            //The model doesn't need to exist, in its purest form, an MVC triad could just be a view

            if (class_exists($modelName))  $rule->shareInstances[] = $modelName;

            

            

            //Add the rule to the DIC

            $this->dice->addRule('$autoRoute_' . $className, $rule);

        }

        

        //Create the route object

        return $this->dice->create('$autoRoute_' . $className);

    }

}
?>