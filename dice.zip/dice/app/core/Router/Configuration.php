<?php
namespace Router;

class Configuration implements \Router\Rule {

    private $dice;



    public function __construct(\Dice\Dice $dice) {

        $this->dice = $dice;

    }



    public function find(array $route) {


        $name = '$route_' . $route[0] . '/' . $route[1];

// print_r($name);

        //If there is no special rule set up for this $name, revert to the default

        if ($this->dice->getRule($name) == $this->dice->getRule('*')) {

            return false;

        }

        else return $this->dice->create($name);

    }

}
?>