<?php
namespace Router;

class Default implements \Router\Rule {

    private $dice;



    public function __construct(\Dice\Dice $dice) {

        $this->dice = $dice;

    }



    public function find(array $route) {

        return $this->dice->create('$route_default');    

    }

}
?>