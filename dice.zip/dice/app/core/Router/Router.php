<?php

// previous tutorial

// class Router {

// 	private $table = array();
	
// 	public function __construct() {
// 		$this->table['controller'] = new Route('Model', 'View', 'Controller');  
// 	}
	
// 	public function getRoute($route) {
// 		$route = strtolower($route);

// 		//Return a default route if no route is found
// 		if (!isset($this->table[$route])) {
// 			return $this->table['controller'];	
// 		}
		
// 		return $this->table[$route];		
// 	}
// }


namespace Router;



interface Rule {

    public function find(array $route);

}



class Router {

    private $rules = array();

    

    public function addRule(Rule $rule) {
        

        $this->rules[] = $rule;

    }

    public function getRoute(array $route) {
        
        try{
            
        foreach ($this->rules as $rule) {

                if ($found = $rule->find($route))


                return $found;    


            }
            
            throw new \Exception('No matching route found');

        }catch(\Exception $e){
                print($e->getMessage());
        }

        

    }

}

?>