<?php
require_once 'Dice.php';
require_once 'tests/DiceTest.php';
