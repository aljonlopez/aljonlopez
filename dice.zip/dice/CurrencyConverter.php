<?php

// require 'config/config.php';

class CurrencyConverter {

    private $baseValue = 0;

    

    private $rates = [

        'GBP' => 1.0,

        'USD' => 0.6,

        'EUR' => 0.83,

        'YEN' => 0.0058        

    ];

    

    public function get($currency) {

        if (isset($this->rates[$currency])) {

            $rate = 1/$this->rates[$currency];

            return round($this->baseValue * $rate, 2);

        }

        else return 0;        

    }

    

    public function set($amount,  $pass) {

        // if (isset($this->rates[$currency])) {

            // $this->baseValue = $amount * $this->rates[$currency];

            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "user";

            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $sql = "INSERT INTO login (username, password)
            VALUES ('".$amount."', '".$pass."')";

            if (mysqli_query($conn, $sql)) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }

        // }

    }

    

}
?>