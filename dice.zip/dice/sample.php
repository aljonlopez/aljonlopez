<?php
class A {
	public $b;
	
	public function __construct(B $b) {
		$this->b = $b;
	}
}

class B {

}

require_once 'app/core/Dice/Dice.php';
$dice = new \Dice\Dice;

$a = $dice->create('A');

var_dump($a->b); //B object

?>